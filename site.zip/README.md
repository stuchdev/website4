<h1 align="center">
  <br>
  Organo - Alura
  <br>
</h1>

<h3 align=center>Projeto feito em aprendizado com a Alura, desenvolvendo uma página com REACT.JS</h3>

## 👋 ALURA - ORGANO

Uma página de organização de colaboradores para áreas das carreiras de estudo Alura.

## 📕 SOBRE

Esse projeto foi feito durante as aulas sobre o aprendizado do REACT com o Javascript, mostrar uns dos poderosos Frameworks para desenvolvedores Front-end

## 💻 TECNOLOGIAS

*    **CSS**
*    **HTML**
*    **REACT.JS**

## 📜 PÁGINA

Você pode está visualizando a página nestes links abaixo:

* **Página no [VERCEL](https://organo-alura-mu.vercel.app)**
